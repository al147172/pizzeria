<!DOCTYPE html>
<?php

require_once '../includes/resfunctions.php';
checklogin();

?>
<html>
	<head>
		<title>Resultados de la busqueda</title>
		<meta charset="UTF-8">
		</head>
	<body>
	
	<?php
		$conexion = mysqli_connect("localhost","root","","restaurantv4") or die("Problema en la conexion");
		$consulta = $conexion->query("SELECT * FROM ingredientes");
		
		
		
		echo "<table border='1'>";
		echo "<tr><th>Id</th><th>Nombre</th><th>Cantidad</th></tr>";
		$id_ing=1;
		while($renglon = $consulta->fetch_array())
		{
			echo "<tr><td> $id_ing	</td>";
			echo "<td>".$renglon["nombre"]."</td>";
			echo "<td>".$renglon["cantidad"]."</td> </tr>";
			$id_ing=$id_ing+1;
		}
		echo "</table>";
		
		$consulta->free();
		$conexion->close();
		echo "<a href='../panel.php'>Regresar a la pagina principal</a>";	
	?>
	<form action="modificarupdatesql.php" method="get">
	Introduzca id del ingrediente a abastecer: <input type="text"  name="idingr"><br>
	<input type="submit" value="Abastecer">
	</form>
	
	
	</body>
</html>