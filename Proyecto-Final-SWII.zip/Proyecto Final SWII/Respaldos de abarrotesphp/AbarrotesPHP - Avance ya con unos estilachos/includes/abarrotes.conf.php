<?php
/*  _    _                          _            ____  _   _ ____  
   / \  | |__   __ _ _ __ _ __ ___ | |_ ___  ___|  _ \| | | |  _ \ 
  / _ \ | '_ \ / _` | '__| '__/ _ \| __/ _ \/ __| |_) | |_| | |_) |
 / ___ \| |_) | (_| | |  | | | (_) | ||  __/\__ \  __/|  _  |  __/ 
/_/   \_\_.__/ \__,_|_|  |_|  \___/ \__\___||___/_|   |_| |_|_|    
      Desarrollado por Jesús Herrera - www.vivegroup.org
*/



// Hosting
define('HOST', 'localhost');

//Base de datos
define('DBASE', 'restaurantv4');

// Usuario
define('DBUSER', 'root');

// Contraseña
define('DBPASSWORD', '');