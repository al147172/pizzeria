<?php 
/*  _    _                          _            ____  _   _ ____  
   / \  | |__   __ _ _ __ _ __ ___ | |_ ___  ___|  _ \| | | |  _ \ 
  / _ \ | '_ \ / _` | '__| '__/ _ \| __/ _ \/ __| |_) | |_| | |_) |
 / ___ \| |_) | (_| | |  | | | (_) | ||  __/\__ \  __/|  _  |  __/ 
/_/   \_\_.__/ \__,_|_|  |_|  \___/ \__\___||___/_|   |_| |_|_|    
      Desarrollado por Jesús Herrera - www.vivegroup.org
*/
require_once 'conexion.class.php';session_start();class Login{private static $instancia;private $dbh;private function __construct(){$this->dbh = Conexion::singleton_conexion();}public static function singleton_login(){if (!isset(self::$instancia)) {$miclase = __CLASS__;self::$instancia = new $miclase;}return self::$instancia;}public function login_users($usuario,$password){try {$SAL = 'AWR004z5o8Ub6Fb8hM4Qijy5UyJn736t';$PIMIENTA = 'qYfd010Ca4UGPUA6MY6pY51Zklv7GVjY';$ResCrypt = sha1($SAL.$password.$PIMIENTA);$sql = "SELECT * FROM usuarios WHERE usuario = ? AND password = ?";$query = $this->dbh->prepare($sql);$query->bindParam(1,$usuario);$query->bindParam(2,$ResCrypt );$query->execute();$this->dbh = null;if($query->rowCount() == 1){$fila  = $query->fetch();$_SESSION['idsession'] = $fila['id'];$_SESSION['ranksession'] = $fila['rango'];return TRUE;}else return FALSE;}catch(PDOException $e){print "Error!: " . $e->getMessage();}}public function __clone(){trigger_error('La clonación de este objeto no está permitida', E_USER_ERROR);}}