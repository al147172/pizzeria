<?php
/*  _    _                          _            ____  _   _ ____  
   / \  | |__   __ _ _ __ _ __ ___ | |_ ___  ___|  _ \| | | |  _ \ 
  / _ \ | '_ \ / _` | '__| '__/ _ \| __/ _ \/ __| |_) | |_| | |_) |
 / ___ \| |_) | (_| | |  | | | (_) | ||  __/\__ \  __/|  _  |  __/ 
/_/   \_\_.__/ \__,_|_|  |_|  \___/ \__\___||___/_|   |_| |_|_|    
      Desarrollado por Jesús Herrera - www.vivegroup.org
*/
error_reporting(E_ALL ^ E_NOTICE);class Conexion{private static $instancia;private $dbh;private function __construct(){try {require_once 'abarrotes.conf.php';$host = HOST;$db =   DBASE;$user = DBUSER;$pwd =  DBPASSWORD;$this->dbh = new PDO('mysql:host='.$host.';dbname='.$db, $user, $pwd);$this->dbh->exec("SET CHARACTER SET utf8");} catch (PDOException $e) {print "Error!: " . $e->getMessage();die();}}public function prepare($sql){return $this->dbh->prepare($sql);}public static function singleton_conexion(){if (!isset(self::$instancia)) {$miclase = __CLASS__;self::$instancia = new $miclase;}return self::$instancia;}public function __clone(){trigger_error('La clonación de este objeto no está permitida', E_USER_ERROR);}public function lastInsertId(){return $this->dbh->lastInsertId();}}