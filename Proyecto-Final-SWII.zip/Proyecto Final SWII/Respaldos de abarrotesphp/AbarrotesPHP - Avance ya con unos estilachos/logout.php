<?php
/*  _    _                          _            ____  _   _ ____  
   / \  | |__   __ _ _ __ _ __ ___ | |_ ___  ___|  _ \| | | |  _ \ 
  / _ \ | '_ \ / _` | '__| '__/ _ \| __/ _ \/ __| |_) | |_| | |_) |
 / ___ \| |_) | (_| | |  | | | (_) | ||  __/\__ \  __/|  _  |  __/ 
/_/   \_\_.__/ \__,_|_|  |_|  \___/ \__\___||___/_|   |_| |_|_|    
      Desarrollado por Jesús Herrera - www.vivegroup.org
*/
session_start();session_regenerate_id();unset($_SESSION['idsession']);unset($_SESSION['ranksession']);session_destroy();header('Location: index.php');
