<?php

require_once 'login.class.php';

// Traer el Nombre ///
function getName(){

   $conexion = Conexion::singleton_conexion();

   $SQL = 'SELECT * FROM configuracion WHERE id = 1';
   $sentence = $conexion -> prepare($SQL);
   $sentence -> execute();
   $resultados = $sentence -> fetchAll();
   if (empty($resultados)){
  # code...
   }else{
      foreach ($resultados as $key){
        if ($key['logo'] == 1) {
            echo $key['nombre'];
        }else{
            echo $key['logo'];
        }
     }
  }

  $conexion = null;

}

function abastecering($id_ing)
{
   $conexion = Conexion::singleton_conexion();
   $SQL = "UPDATE ingredientes SET cantidad = 1000 WHERE id = 1";
   $sentence = $conexion -> prepare($SQL);
   $sentence -> execute();
   $conexion = null;
}


// validacion pequeña de algunas cosas
function simpleFilterSpace($string){
    if (empty($string))
    {
      exit;
    }
    elseif (ctype_space($string))
    {
      exit;
    }else{
      return $string;
    }

}


// Complementos
function theUserType(){ // aqui se escribe todo lo del menu

   if ($_SESSION['ranksession'] == 2) { //el menu que ves dependiendo si eres administrador
     echo'
<br><br>
<div class="col-md-6 col-sm-6 col-xs-12">
    <button data-option="1" class="optionspress BotonPDV"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Punto de venta</button>
</div>

<br><br><br>
<div class="col-md-6 col-sm-6 col-xs-12">
    <button data-option="2" class="optionspress BotonCategorias"><i class="fa fa-tag" aria-hidden="true"></i> Categorias</button>
</div>

<br><br><br>
<div class="col-md-6 col-sm-6 col-xs-12">
    <button data-option="3" class="optionspress BotonProductos"><i class="fa fa-shopping-basket" aria-hidden="true"></i> Productos</button>
</div>

<br><br><br>
<div class="col-md-6 col-sm-6 col-xs-12">
    <button data-option="4" class="optionspress BotonUsuarios"><i class="fa fa-user-o" aria-hidden="true"></i> Usuarios</button>
</div>

<!--- 
<div class="col-md-6 col-sm-6 col-xs-12">
    <button data-option="5" class="optionspress btn btn-lg btn-block btn-info"><i class="fa fa-table" aria-hidden="true"></i> Bitacora</button>
</div>
-->

     ';
   }else{
echo'
<br><br>
<div class="col-md-6 col-sm-6 col-xs-12">
	
    <button data-option="1" class="optionspress BotonPDV"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Punto de venta</button>
</div>

';
   }




}





// Simple Login Function ///
function thelogin($email,$password){
  $nuevoSingleton = Login::singleton_login();
    $usuario = $nuevoSingleton->login_users($email,$password);
    if($usuario == TRUE){header("Location: panel.php");}
    if($usuario == FALSE){header("Location: index.php?error");}
}



/// Revisar si el usuario esta logeado ///
function checklogin(){
  if (isset($_SESSION['idsession'])){
  }else{
    header('Location: logout.php');
  }
}


/// Revisar si el usuario esta logeado ///
function checkloginstart(){
  if (isset($_SESSION['idsession'])){
    header('Location: panel.php');
  } 
}


/// Saber si la sesion es existente
function checksessionrequest(){
  if (isset($_SESSION['idsession'])){
  }else{
    exit;
  }
}

// Si el que hace las modificaciones es administrador
function isadmin(){
  if ($_SESSION['ranksession'] == 2) {
  }else{
    exit;
  }
}


// Nombre de Usuario
function getNameUser(){

  $conexion = Conexion::singleton_conexion();

  $SQL = 'SELECT * FROM usuarios WHERE id = :id';
  $sentence = $conexion -> prepare($SQL);
  $sentence -> bindParam(':id', $_SESSION['idsession'], PDO::PARAM_INT);
  $sentence -> execute();
  $resultados = $sentence -> fetchAll();
  if (empty($resultados)){
        $conexion = null;
  }else{
     foreach ($resultados as $key){
        echo $key['usuario'];
     }
  }
  $conexion = null;
}


function categoriasSelect(){

  $conexion = Conexion::singleton_conexion();

  $SQL = 'SELECT * FROM categorias';
  $sentence = $conexion -> prepare($SQL);
  $sentence -> bindParam(':id', $_SESSION['idsession'], PDO::PARAM_INT);
  $sentence -> execute();
  $resultados = $sentence -> fetchAll();
  if (empty($resultados)){
        $conexion = null;
  }else{
     foreach ($resultados as $key){
        echo '<option value="'.$key['id'].'">'.$key['nombre'].'</option>';
     }
  }
  $conexion = null;  
}


function categoriasSelectPerID($categoria){

  $conexion = Conexion::singleton_conexion();

  $SQL = 'SELECT * FROM categorias WHERE id = :id';
  $sentence = $conexion -> prepare($SQL);
  $sentence -> bindParam(':id', $categoria, PDO::PARAM_INT);
  $sentence -> execute();
  $resultados = $sentence -> fetchAll();
  if (empty($resultados)){
        $conexion = null;
  }else{
     foreach ($resultados as $key){
        echo '<option value="'.$key['id'].'">'.$key['nombre'].'</option>';
     }
  }
  $conexion = null;  
}


// Nombre de Usuario
function getNameCategory($categoria){

  $conexion = Conexion::singleton_conexion();

  $SQL = 'SELECT nombre FROM categorias WHERE id = :id';
  $sentence = $conexion -> prepare($SQL);
  $sentence -> bindParam(':id', $categoria, PDO::PARAM_INT);
  $sentence -> execute();
  $resultados = $sentence -> fetchAll();
  if (empty($resultados)){
        $conexion = null;
  }else{
     foreach ($resultados as $key){
        return $key['nombre'];
     }
  }
  $conexion = null;
}



function checkusernameDB($usuario){

  $conexion = Conexion::singleton_conexion();

  $SQL = 'SELECT usuario FROM usuarios WHERE usuario = :usuario LIMIT 1';
  $sentence = $conexion -> prepare($SQL);
  $sentence -> bindParam(':usuario', $usuario, PDO::PARAM_INT);
  $sentence -> execute();
  $resultados = $sentence -> fetchAll();
  if (empty($resultados)){
      return 1;
  }else{
      return 2;
  }
  $conexion = null;

}







function GETcategoriasCaja(){

   $conexion = Conexion::singleton_conexion();

   $SQL = 'SELECT * FROM categorias';
   $stn = $conexion -> prepare($SQL);
   $stn -> execute();
   $results = $stn -> fetchAll();
   if (empty($SQL)){
   }else{

       foreach ($results as $key){
        
           echo '
				<!--br-->
                <div class=" col-md-4 col-sm-4 ">
                <button data-categoria="'.$key['id'].'" class="restaurantcatbtn categoriabtn BotonGetCategoria"><i class="fa fa-chevron-right" aria-hidden="true"></i> '.$key['nombre'].'</button>
                </div>
           ';

       }

   }

   $conexion = null;

}



function GETproductosCaja($productos){

   $conexion = Conexion::singleton_conexion();

   $SQL = 'SELECT * FROM productos WHERE categoria = :categoria';
   $stn = $conexion -> prepare($SQL);
   $stn -> bindParam(':categoria', $productos, PDO::PARAM_INT);
   $stn -> execute();
   $results = $stn -> fetchAll();
   if (empty($SQL)){
   }else{

       foreach ($results as $key){
        
           if ($key['cantidad'] == 0){
           echo '
                <div class="col-md-4 col-sm-4">
                <button id="theproductitem'.$key['id'].'" data-nombre="'.$key['nombre'].'" data-maximo="'.$key['cantidad'].'"  data-precio="'.$key['precio'].'" class="productobtnresult btn btn-danger btn-lg btn-block animated flash" onclick="agregarcaja('.$key['id'].')" disabled><i class="fa fa-cutlery" aria-hidden="true"></i> '.$key['nombre'].' <p>($'.$key['precio'].')</p></button>
                </div>
           ';      
           }else{
           echo '
                <div class="col-md-4 col-sm-4">
                <button id="theproductitem'.$key['id'].'" data-nombre="'.$key['nombre'].'" data-maximo="'.$key['cantidad'].'"  data-precio="'.$key['precio'].'" class="productobtnresult btn btn-warning btn-lg btn-block" onclick="agregarcaja('.$key['id'].')"><i class="fa fa-cutlery" aria-hidden="true"></i> '.$key['nombre'].' <p><strong>$'.$key['precio'].'</strong></p></button>
                </div>
           ';            
           }



       }

   }

   $conexion = null;

}

function resta_ingredientes($idpizza, $cantidad_pizza, $idingredientea, $idingredienteb, $idingredientec)
{
		$cant_pizza=$cantidad_pizza;
		$conexion = Conexion::singleton_conexion();
		$SQL = 'SELECT * FROM productos WHERE id = $idpizza';   
		$sentence = $conexion -> prepare($SQL);
		$sentence -> execute();
		$resultados = $sentence -> fetchAll();
		if (empty($resultados)){
		}else{
			foreach ($resultados as $key){
				//$id_inga = $key['id'];
				$precio = $key['precio'];
			}

		}
		/* Resta del primer ingrediente */
		//$id_inga=$idingredientea;
		//$idingredientea=12;
		$SQL = "SELECT * FROM ingredientes WHERE id = '$idingredientea'";
		$sentence = $conexion -> prepare($SQL);
		$sentence -> execute();
		$resultados = $sentence -> fetchAll();	
		if (empty($resultados)){
		}else{
			foreach ($resultados as $key){
				$cantidad = $key['cantidad'];
			}

		}
		$resta = $cantidad - (20*$cant_pizza);
		//$id_inga=$idingredientea;
		$SQLInv = "UPDATE ingredientes SET cantidad = '$resta' WHERE id = '$idingredientea'";
		$sentence = $conexion -> prepare($SQLInv);
		//$sentence -> bindParam(':cantidad',$resta,PDO::PARAM_INT);
		//$sentence -> bindParam(':id',$$idingredientea,PDO::PARAM_INT);
		$sentence -> execute();
		/* Resta del segundo ingrediente (si hay)*/
		if($idingredienteb != 0)
		{
			$SQL = "SELECT * FROM ingredientes WHERE id = '$idingredienteb'";
			$sentence = $conexion -> prepare($SQL);
			$sentence -> execute();
			$resultados = $sentence -> fetchAll();	
			if (empty($resultados)){
			}else{
				foreach ($resultados as $key){
					$cantidad = $key['cantidad'];
				}
	
			}
			$resta = $cantidad - (20*$cantidad_pizza);
			//$id_inga=$idingredienteb;
			$SQLInv = "UPDATE ingredientes SET cantidad = '$resta' WHERE id = '$idingredienteb'";
			$sentence = $conexion -> prepare($SQLInv);
			//$sentence -> bindParam(':cantidad',$resta,PDO::PARAM_INT);
			//$sentence -> bindParam(':id',$id_inga,PDO::PARAM_INT);
			$sentence -> execute();
		}
		/* Resta del tercer ingrediente (tambien si hay)*/
		if($idingredientec != 0)
		{
			$SQL = "SELECT * FROM ingredientes WHERE id = '$idingredientec'";
			$sentence = $conexion -> prepare($SQL);
			$sentence -> execute();
			$resultados = $sentence -> fetchAll();	
			if (empty($resultados)){
			}else{
				foreach ($resultados as $key){
					$cantidad = $key['cantidad'];
				}
	
			}
			$resta = $cantidad - (20*$cantidad_pizza);
			$id_inga=$idingredientec;
			$SQLInv = "UPDATE ingredientes SET cantidad = '$resta' WHERE id = '$idingredientec'";
			$sentence = $conexion -> prepare($SQLInv);
			//$sentence -> bindParam(':cantidad',$resta,PDO::PARAM_INT);
			//$sentence -> bindParam(':id',$id_inga,PDO::PARAM_INT);
			$sentence -> execute();
		}
		
		$conexion = null;
}

function getDataProductsVenta($thedata){

   
   $conexion = Conexion::singleton_conexion();
   $explodedata = explode('|', $thedata);
   
   // Id del Producto
   $explodedata[0];
   // Cantidad
   $explodedata[1];

   //****************** saber que tipo de pizza es ******* Decide que ingredientes restar
   /**********************/
   
   
   if($explodedata[0]==16) /* Pizza de pepperoni : Resta solo el ingrediente de pepperoni*/
   {
		resta_ingredientes($explodedata[0], $explodedata[1], 12, 0, 0);
   }
   
   if($explodedata[0]==20) /* Pizza hawaiana : Resta los ingredientes: pina y jamon */
   {
	   resta_ingredientes($explodedata[0], $explodedata[1], 13, 8, 0);
   }
   
   if($explodedata[0]==21) /* Pizza bolognesa : Resta los ingredientes: tomate, carne, y (queso) mozzarella */
   {
	   resta_ingredientes($explodedata[0], $explodedata[1], 17, 3, 14);
   }
   
   if($explodedata[0]==23) /* Pizza mozzarella : Resta los ingredientes: tomate, mozzarella, y aceitunas */
   {
	   resta_ingredientes($explodedata[0], $explodedata[1], 17, 14, 1);
   }
   
   if($explodedata[0]==24) /* Pizza atun : Resta los ingredientes: atun, salami y pepperoni */
   {
	   resta_ingredientes($explodedata[0], $explodedata[1], 2, 15, 12);
   }
   
   if($explodedata[0]==25) /* Pizza Mexicana de carne : Resta los ingredientes: Carne, cebolla, y tocino */
   {
	   resta_ingredientes($explodedata[0], $explodedata[1], 3, 4, 16);
   }
   
   if($explodedata[0]==26) /* Pizza Mexicana de carne sin cebolla : Resta los ingredientes: Carne, jamon y tocino */
   {
	   resta_ingredientes($explodedata[0], $explodedata[1], 3, 8, 16);
   }
   
   if($explodedata[0]==27) /* Pizza Picante : Resta los ingredientes: chorizo, jalapenos y morron */
   {
	   resta_ingredientes($explodedata[0], $explodedata[1], 6, 7, 10);
   }
   
   if($explodedata[0]==28) /* Pizza de champinones : Resta los ingredientes: champinones, y aceitunas */
   {
	   resta_ingredientes($explodedata[0], $explodedata[1], 5, 1, 0);
   }
   
   
   /*********************/
   
   // Sentencia SQL
   $SQL = 'SELECT * FROM productos WHERE id = :id';
   $sentence = $conexion -> prepare($SQL);
   $sentence -> bindParam(':id',$explodedata[0],PDO::PARAM_INT);
   $sentence -> execute();
   
   
   $resultados = $sentence -> fetchAll();
   if (empty($resultados)){
   }else{
      foreach ($resultados as $key){
        $cantidad = $key['cantidad'];
        $precio = $key['precio'];
      }

   }

   $resta = $cantidad - $explodedata[1];
   
   $SQLInv = 'UPDATE productos SET cantidad = :cantidad WHERE id = :id';
   $sentence = $conexion -> prepare($SQLInv);
   $sentence -> bindParam(':cantidad',$resta,PDO::PARAM_INT);
   $sentence -> bindParam(':id',$explodedata[0],PDO::PARAM_INT);
   $sentence -> execute();

   $conexion = null;
//	*/
   $sumaprecios = $explodedata[1] * $precio;
   return $sumaprecios;
	
}



function guardarVenta($cadena,$venta){

$conexion = Conexion::singleton_conexion();

// Fecha
$dateseconds = date('Y-m-d h:i:s');
$datenormal = date('Y-m-d');

// Guardar la venta realizada
$SQL = 'INSERT INTO ventas(fecha,fechaseconds,usuario,ticket,total) VALUES(:fecha,:fechaseconds,:usuario,:ticket,:total)';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':fecha',$datenormal,PDO::PARAM_STR);
$sentence -> bindParam(':fechaseconds',$dateseconds,PDO::PARAM_STR);
$sentence -> bindParam(':usuario',$_SESSION['idsession'],PDO::PARAM_INT);
$sentence -> bindParam(':ticket',$cadena,PDO::PARAM_STR);
$sentence -> bindParam(':total',$venta,PDO::PARAM_STR);
$sentence -> execute();
$conexion = null;
}




function getProDataVenta($thedataticket){

       $conexion = Conexion::singleton_conexion();

       // Primer Explode
       $firstexplode = explode(',', $thedataticket);

       // Contar los item en el explode
       $countexplode = count($firstexplode);

       
       for ($i = $countexplode; $i >= 0; $i--){
           
                // Second Explode
                $secondexplode = explode('|',$firstexplode[$i]);

                // Id Producto
                $secondexplode[0];
                // Cantidad
                $secondexplode[1];

                // Sentencia SQL Consulta
                $SQL = 'SELECT nombre FROM productos WHERE id = :id';
                $sentence = $conexion -> prepare($SQL);
                $sentence -> bindParam(':id',$secondexplode[0],PDO::PARAM_INT);
                $sentence -> execute();
                $resultados = $sentence -> fetchAll();
                foreach ($resultados as $key){
                  
                    echo '<p><i class="fa fa-cutlery" aria-hidden="true"></i> '.$key['nombre'].' <label class="label label-primary">Cantidad: '.$secondexplode[1].'</label></p>';

                }


       }

   $conexion = null;
}