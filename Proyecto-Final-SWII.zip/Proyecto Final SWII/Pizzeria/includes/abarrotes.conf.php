<?php




// Hosting
define('HOST', 'localhost');

//Base de datos
define('DBASE', 'restaurantv4');

// Usuario
define('DBUSER', 'root');

// Contraseña
define('DBPASSWORD', '');