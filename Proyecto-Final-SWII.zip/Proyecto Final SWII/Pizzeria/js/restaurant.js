
function closecontent()
{
	$("#theoptioncontent").fadeOut(500);
	$("#theoptioncontent").html("")
}

$(".optionspress").on("click",function(){var a=$(this).attr("data-option"),b="process="+a;
1==a?window.open("caja.php"):$.ajax(
{
	type:"POST",url:"includes/processfunction.php",data:b,beforeSend:function()
	{
		$("#theoptioncontent").fadeIn(500);
		$("#theoptioncontent").html
		('<a onclick="closecontent();" id="closecontent"><i class="fa fa-times-circle" aria-hidden="true"></i></a><div id="theloaditemcontent" class="line-scale"><div></div><div></div><div></div><div></div><div></div></div>')
	},success:
	function(a)
	{
		$("#theoptioncontent").html("");
		$("#theoptioncontent").append('<div id="content-process">'+a+'</div><div id="modal-content" class="text-left"></div>')},error:function(){}})});
		function nuevaCategoria()
		{
			jQuery.validator.setDefaults({debug:!0,success:"valid",ignore:[]});
			var a=$("#categoriaForm");
			a.validate({rules:{nombre:"required"},messages:{nombre:"Campo obligatorio."}});
			if(1==a.valid()){var b=a.serialize();
			$.ajax(
			{
				type:"POST",url:"includes/processfunction.php",data:"process=7&"+b,beforeSend:
				function()
				{
					a.hide();
					a.parent().append('<div id="theloaderfrm" class="line-scale-party"><div></div><div></div><div></div><div></div></div>')},success:function(b){$("#myModal").modal("toggle");a.show();$("#theloaderfrm").remove();$("#thetbodyproductos").append(b);a[0].reset()},error:function(){}})}}
		function EditCategoria(a)
		{
			$.ajax({type:"POST",url:"includes/processfunction.php",
			data:"process=8&categoria="+a,
			beforeSend:function(){$("#modal-content").html("")},success:function(a){$("#modal-content").append(a);
			$("#myModalEdit").modal("show")},error:function(){}})}function SaveChangeCategoria(a){jQuery.validator.setDefaults({debug:!0,
			success:"valid",ignore:[]});
			var b=$("#categoriaFormEdit");
			b.validate({rules:{nombre:"required"},messages:{nombre:"Campo obligatorio."}});
			if(1==b.valid()){var c=b.serialize();
			$.ajax({type:"POST",url:"includes/processfunction.php",data:"process=9&"+c+"&categoria="+a,beforeSend:function(){b.hide();
			b.parent().append('<div id="theloaderfrm" class="line-scale-party"><div></div><div></div><div></div><div></div></div>')},
			success:function(b){$("#myModalEdit").modal("toggle");
			$(".CatNameTD"+a).html(b)},
			error:function(){}})}}
			function DeleteCategoria(a){$.ajax({type:"POST",url:"includes/processfunction.php",data:"process=10&categoria="+a,beforeSend:function(){$("#modal-content").html("")},success:function(b){$("#trClass"+a).addClass("animated bounceOut").fadeOut(1E3)},error:function(){}})}function nuevoProducto(){jQuery.validator.setDefaults({debug:!0,success:"valid",ignore:[]});var a=$("#ProductosForm");a.validate({rules:{nombre:"required",categoria:"required",cantidad:"required",precio:"required"},messages:{nombre:"Campo obligatorio.",categoria:"Campo obligatorio.",cantidad:"Campo obligatorio.",precio:"Campo obligatorio."}});if(1==a.valid()){var b=a.serialize();$.ajax({type:"POST",url:"includes/processfunction.php",data:"process=11&"+b,beforeSend:function(){a.hide();a.parent().append('<div id="theloaderfrm" class="line-scale-party"><div></div><div></div><div></div><div></div></div>')},success:function(b){$("#myModal").modal("toggle");a.show();$("#theloaderfrm").remove();$("#thetbodyproductos").append(b);a[0].reset()},error:function(){}})}}
			function EditProducto(a)
			{
				$.ajax({type:"POST",url:"includes/processfunction.php",data:"process=12&producto="+a,
				beforeSend:function()
				{
					$("#modal-content").html("")},success:function(a){$("#modal-content").append(a);
					$("#myModalEdit").modal("show")},
					error:function(){}})}function SaveChangeProducto(a){jQuery.validator.setDefaults({debug:!0,success:"valid",ignore:[]});
					var b=$("#ProductosFormEdit");
					b.validate(
					{
						rules:
						{
							nombre:"required",
							categoria:"required",
							cantidad:"required",
							precio:"required"
						},
						messages:
						{
							nombre:"Campo obligatorio.",
							categoria:"Campo obligatorio.",
							cantidad:"Campo obligatorio.",
							precio:"Campo obligatorio."
						}
					});
				if(1==b.valid()){var c=b.serialize();
				$.ajax({type:"POST",url:"includes/processfunction.php",dataType:"json",data:"process=13&"+c+"&producto="+a,
				beforeSend:function(){b.hide();
				b.parent().append('<div id="theloaderfrm" class="line-scale-party"><div></div><div></div><div></div><div></div></div>')},
				success:function(b){$("#myModalEdit").modal("toggle");
				$(".ProTDName"+a).html(b.nombre+'<small class="preciPro">$'+b.precio+"</small>");
				$(".smallProData"+a).html('<i class="fa fa-tag" aria-hidden="true"></i> '+b.categoria)},
				error:function(){}})
				}
			}
			function DeleteProducto(a){$.ajax({type:"POST",
			url:"includes/processfunction.php",
			data:"process=14&producto="+a,
			beforeSend:function(){$("#modal-content").html("")},
			success:function(b){$("#trClassPro"+a).addClass("animated bounceOut").fadeOut(1E3)},
			error:function(){}})}function nuevoUsuario(){jQuery.validator.setDefaults({debug:!0,success:"valid",ignore:[]});var a=$("#NuevoUsuarioFrm");a.validate({rules:{usuario:"required",password:"required",rango:"required"},messages:{usuario:"Campo obligatorio.",password:"Campo obligatorio.",rango:"Campo obligatorio."}});if(1==a.valid()){var b=a.serialize();$.ajax({type:"POST",url:"includes/processfunction.php",data:"process=15&"+b,beforeSend:function(){a.hide();a.parent().append('<div id="theloaderfrm" class="line-scale-party"><div></div><div></div><div></div><div></div></div>')},success:function(b){2==b?($("#theloaderfrm").remove(),$("#UserExistNotification").show(),a.show(),setTimeout(function(){$("#UserExistNotification").fadeOut()},3E3)):($("#myModal").modal("toggle"),a.show(),$("#theloaderfrm").remove(),$("#tbodyusuarios").append(b))},error:function(){}})}}function EditUsuarios(a){$.ajax({type:"POST",url:"includes/processfunction.php",data:"process=16&usuario="+a,beforeSend:function(){$("#modal-content").html("")},success:function(a){$("#modal-content").append(a);$("#myModalEdit").modal("show")},error:function(){}})}function SaveChangeUsuario(a){jQuery.validator.setDefaults({debug:!0,success:"valid",ignore:[]});var b=$("#UsuariosFrmEdit");b.validate({rules:{usuario:"required",rango:"required"},messages:{usuario:"Campo obligatorio.",rango:"Campo obligatorio."}});if(1==b.valid()){var c=b.serialize();$.ajax({type:"POST",url:"includes/processfunction.php",dataType:"json",data:"process=17&"+c+"&iduser="+a,beforeSend:function(){b.hide();b.parent().append('<div id="theloaderfrm" class="line-scale-party"><div></div><div></div><div></div><div></div></div>')},success:function(c){2==c.erroruser?($("#UserExistNotification").show(),$("#theloaderfrm").remove(),b.show(),setTimeout(function(){$("#UserExistNotification").fadeOut()},3E3)):($("#myModalEdit").modal("toggle"),$(".UserTDName"+a).html('<i class="fa fa-user-o" aria-hidden="true"></i> '+c.usuario),$(".UserRankData"+a).html(c.rango))},error:function(){}})}}function DeleteUsuarios(a){$.ajax({type:"POST",url:"includes/processfunction.php",data:"process=18&usuario="+a,beforeSend:function(){$("#modal-content").html("")},success:function(b){$("#TrUsuario"+a).addClass("animated bounceOut").fadeOut(1E3)},error:function(){}})}$(".restaurantcatbtn").on("click",function(){var a=$(this).attr("data-categoria");$.ajax({type:"POST",url:"includes/processfunction.php",data:"process=19&categoria="+a,beforeSend:function(){$("#menu-panel-productos").append('<div class="cssload-thecube"><div class="cssload-cube cssload-c1"></div><div class="cssload-cube cssload-c2"></div><div class="cssload-cube cssload-c4"></div><div class="cssload-cube cssload-c3"></div></div>')},success:function(a){$("#menu-panel-productos").html(a)},error:function(){}})});
function agregarcaja(a)
{
	var b=$("#theproductitem"+a).attr("data-nombre");
	$("#theproductitem"+a).attr("data-stock");
	var c=$("#theproductitem"+a).attr("data-precio"),e=$("#theproductitem"+a).attr("data-maximo"),d=$("#cajaitem"+a),f=$("#theinputsum");
	$(d).length||(""==f.val()?(f.val(c),$("#total").text("Total a pagar: $"+c)):(d=f.val(),d=parseFloat(d)+parseFloat(c),f.val(d),
	$("#total").text("Total a pagar: $"+d)),$("#theproducts").append('<span id="cajaitem'+a+'" data-precio="'+c+'" data-max="'+e+'" data-id="'+a+'" data-cantidad="1" class="btn btn-block btn-sm">'+b+" [$"+c+'] <p id="thepitemcantidad'+a+'" class="pull-right cantidad-item-p">1</p> <button style="margin-left:4px;" onclick="cantidadProductoPlus('+a+')" class="btn btn-xs btn-success pull-right"><i class="fa fa-plus-square" aria-hidden="true"></i></button> <button class="btn btn-xs btn-danger pull-right" onclick="cantidadProductoMinus('+a+')"><i class="fa fa-minus-square"  aria-hidden="true"></i></button> </span>'))
}

function cantidadProductoMinus(a)
{
	$("#cajaiteminput"+a).val();
	var b=$("#cajaitem"+a).attr("data-precio"),
	c=$("#cajaitem"+a).attr("data-cantidad"),
	e=$("#theinputsum").val(),
	d=$("#theinputsum");
	if(1==c)c=parseFloat(e)-parseFloat(b),
	d.val(c),
	0==c?$("#total").text(""):$("#total").text("Total a pagar: $"+c),
	$("#cajaitem"+a).remove();
	else
	{
		var f=parseInt(c)-1,
		c=parseFloat(e)-parseFloat(b);
		d.val(c);
		$("#thepitemcantidad"+a).text(f);
		$("#cajaitem"+a).attr("data-cantidad",f);
		a=parseFloat(e)-parseFloat(b);
		$("#theinputsum").val(a);
		$("#total").text("Total a pagar: $"+a)
	}
}

function cantidadProductoPlus(a)
{
	var b=$("#cajaitem"+a).attr("data-cantidad"),
	c=$("#cajaitem"+a).attr("data-precio"),
	e=$("#cajaitem"+a).attr("data-max"),
	d=$("#theinputsum").val(),
	c=parseFloat(d)+parseFloat(c),
	b=parseInt(b)+1;
	b>e?$("#cajaitem"+a).addClass("animated shake"):($("#thepitemcantidad"+a).text(b),
	$("#cajaitem"+a).attr("data-cantidad",b),
	$("#theinputsum").val(c),
	$("#total").html("Total a pagar: $"+c))
}

function FinalizarVenta()
{
	var a=$("#theproducts span").length;
	for($("#textventa").text("");	0<a;	a--)
	{
		var b=$("#theproducts span:nth-child("+a+")").attr("data-id"),c=$("#theproducts span:nth-child("+a+")").attr("data-cantidad");
	$("#textventa").append(b+"|"+c+",")}a=$("#textventa").text();
	$.ajax(
	{
		type:"POST",url:"includes/processfunction.php",data:"process=20&cadena="+a,beforeSend:function()
		{
			
		},
		success:function(a)
		{
			
		},
		error:function(){}});
		$("#menu-panel-productos").html("");
		$("#theproducts").html("");
		$("#total").html("");
		$("#theinputsum").val("0")
}
function filtrarFecha()
{
			jQuery.validator.setDefaults({debug:!0,success:"valid",ignore:[]});
			var a=$("#formFilterDate");
			a.validate({rules:{filtradofecha:"required"},messages:{filtradofecha:"Campo obligatorio."}});
			1==a.valid()&&(a=a.serialize(),
			$.ajax({type:"POST",url:"includes/processfunction.php",
			data:"process=21&"+a,
			beforeSend:function()
			{
			$("#thefiltrofechabody").
			html('<div id="theloaderfrm" style="padding: 25px;" class="line-scale-party"><div></div><div></div><div></div><div></div></div>')
			},
			success:function(a){$("#thefiltrofechabody").html(a)},error:function(){}}))
};