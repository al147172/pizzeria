<!-- eliminar -->
<!DOCTYPE html>

<html>
	<head>
		<title>Resultados de la busqueda</title>
		<meta charset="UTF-8">
		</head>
	<body>

	<?php
		$conexion = mysqli_connect("localhost","root","","examen") or die("Problema en la conexion");
		if(isset($_REQUEST['matriculamodificar']) )
		{
			$matriculamodificar= $_REQUEST['matriculamodificar'];
			$matricula = "";
			$nombre = "";
			$carrera = "";
			$rock = "";
			$pop = "";
			$jazz = "";
			$blues = "";
			$cumbias = "";
			$genero = "";
			$comentario = "";
		}
		else
		{
			echo "Entrada invalida<br>";
		}	
		
		$conexion = mysqli_connect("127.0.0.1","root","","examen") or die("Problema en la conexion");
		//$consulta = $conexion->query("SELECT * FROM alumnos WHERE matricula = '$matriculamodificar' ");
		
		$query = "SELECT * FROM alumnos WHERE matricula = '$matriculamodificar' ";
		$consulta = $conexion->query("SELECT * FROM alumnos WHERE matricula = '$matriculamodificar' ");

		//Compruebo si hay algún resultado
		if($row = $consulta->fetch_array()){
		//Guardo los datos de la BD en las variables de php
		$matricula = $row["matricula"];
		$nombre = $row["nombre"];
		$carrera = $row["carrera"];
		$rock = $row["rock"];
		$pop = $row["pop"];
		$jazz = $row["jazz"];
		$blues = $row["blues"];
		$cumbias = $row["cumbias"];
		$genero = $row["genero"];
		$comentario = $row["comentario"];
		}
	?>
		
		<form action="modificarupdatesql.php" method="get">
		<input type="hidden" name="matriculaoriginal" value="<?php echo $matricula ?>">
		Matricula: <input type="text"  name="matricula" value="<?php echo $matricula ?>"> <br>
		Nombre: <input type="text"  name="nombre" value="<?php echo $nombre ?>"><br>
		Carrera: <br>
		<input type="radio" name="carrera" value="ingenieria" <?php if (strcasecmp($carrera, 'INGENIERIA') == 0)  { echo "checked"; } else { echo ''; }?>   > Ingenieria <br>
		<input type="radio" name="carrera" value="psicologia" <?php if (strcasecmp($carrera, 'psicologia') == 0)  { echo "checked"; } else { echo '' ;}?>  > Psicologia <br>
		<input type="radio" name="carrera" value="medicina" <?php if (strcasecmp($carrera, 'medicina') == 0)  { echo "checked"; } else { echo ''; }?>    > Medicina <br>
		Generos musicales que te gustan: <br>
		<input type="checkbox" name="grock" value="rock" <?php if ($rock=='rock')  { echo "checked"; } else { echo ''; }?> > Rock <br>
		<input type="checkbox" name="gpop" value="pop" <?php if ($pop=='pop')  { echo "checked"; } else { echo ''; }?> > Pop <br>
		<input type="checkbox" name="gjazz" value="jazz" <?php if ($jazz=='jazz')  { echo "checked"; } else { echo ''; }?> > Jazz <br>
		<input type="checkbox" name="gblues" value="blues" <?php if ($blues=='blues')  { echo "checked"; } else { echo ''; }?> > Blues <br>
		<input type="checkbox" name="gcumbias" value="cumbias" <?php if ($blues=='blues')  { echo "checked"; } else { echo ''; }?> > Cumbias <br>
		Genero: <br>
		<select name="genero">
		<option value="hombre"> Hombre </option>
		<option value="mujer" <?php if ($genero=='mujer')  { echo "selected"; } else { echo ''; }?>  > Mujer </option>
		</select>
		<br>
		Escribe un comentario:<br>
		<textarea rows="5" cols="20" name="comentario"><?php echo $comentario; ?></textarea> <br>
		<input type="submit" value="Actualizar">
		<br><a href="modificar.php">Cancelar</a>
		<br><a href="index.php">Regresar a menu principal</a>
		<br><br>
		</form>
		
	<?php
		
		mysqli_query($conexion,$query) or die("Problema en seleccion de BD".mysql_error());
		mysqli_close($conexion);
	?>
	
	</body>
</html>
	