<?php

require_once 'resfunctions.php';
require_once 'class.inputfilter.php';

if (isset($_POST['process'])) {
//--------------------------------------------------------------------------------

// Tomamos el proceso y lo volvemos variable
$process = $_POST['process'];

// Revisamos si el proceso es numerico, de lo contrario no se acepta.
if (is_numeric($process)) {
//--------------------------------------------------------------------------------


// Variable de Conexion a Base de Datos
$conexion = Conexion::singleton_conexion();


if ($process == 2){
#.................................................................................
checksessionrequest();


// Categorias
$SQL = 'SELECT* FROM categorias';
$sentence = $conexion -> prepare($SQL);
$sentence -> execute();
$resultados = $sentence -> fetchAll();
if (empty($resultados)){

echo'
<a onclick="closecontent();" id="closecontent"><i class="fa fa-times-circle" aria-hidden="true"></i></a>

<button class="btn btn-sm btn-success" data-toggle="modal" data-target="#myModal"><i class="fa fa-tag" aria-hidden="true"></i> Nueva Categoria</button>
<p></p>

<table class="table">
<tbody id="thetbodycategoria"> 
</tbody> 
</table>          
';



// Creacion de nuevas Categorias
echo'
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><i class="fa fa-tag" aria-hidden="true"></i> Nueva Categoria</h4>
      </div>
      <div class="modal-body">
         <form id="categoriaForm">
            <label>Nombre:</label>
            <input type="text" name="nombre" class="form-control">
         </form>
      </div>
      <div class="modal-footer">
        <button type="button" onclick="nuevaCategoria();" class="btn btn-primary">Guardar</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      </div>
    </div>
  </div>
</div>
';


	$conexion = null;
}else{

echo'
<a onclick="closecontent();" id="closecontent"><i class="fa fa-times-circle" aria-hidden="true"></i></a>

<button class="btn btn-sm btn-success" data-toggle="modal" data-target="#myModal"><i class="fa fa-tag" aria-hidden="true"></i> Nueva Categoria</button>
<p></p>
<table class="table">
      <tbody id="thetbodyproductos">
     
';



foreach ($resultados as $key){

    echo'
        
       <tr id="trClass'.$key['id'].'">
         <td><h3 class="CatNameTD'.$key['id'].'">'.$key['nombre'].'</h3></td>
         <td class="text-right">
           <button class="btn btn-sm btn-primary" onclick="EditCategoria('.$key['id'].')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Editar</button>
           <button class="btn btn-sm btn-danger"  onclick="DeleteCategoria('.$key['id'].')"><i class="fa fa-trash-o" aria-hidden="true"></i> Eliminar</button>
         </td>
       </tr>
     
    ';


}

// Final de la Tabla
echo'
       </tbody> 
      </table>
';

// Creacion de nuevas Categorias
echo'
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><i class="fa fa-tag" aria-hidden="true"></i> Nueva Categoria</h4>
      </div>
      <div class="modal-body">
         <form id="categoriaForm">
            <label>Nombre:</label>
            <input type="text" name="nombre" class="form-control">
         </form>
      </div>
      <div class="modal-footer">
        <button type="button" onclick="nuevaCategoria();" class="btn btn-primary">Guardar</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      </div>
    </div>
  </div>
</div>
';

}












#................................................................................	
}elseif ($process == 3){
#.................................................................................
checksessionrequest();




// Categorias
$SQL = 'SELECT productos.id AS ProID, categorias.nombre AS CatName, productos.nombre AS ProName, productos.precio AS ProPrecio, productos.cantidad AS CatCantidad FROM productos INNER JOIN categorias ON productos.categoria = categorias.id';
$sentence = $conexion -> prepare($SQL);
$sentence -> execute();
$resultados = $sentence -> fetchAll();
if (empty($resultados)){


echo'
<a onclick="closecontent();" id="closecontent"><i class="fa fa-times-circle" aria-hidden="true"></i></a>

<button data-toggle="modal" data-target="#myModal" class="btn btn-sm btn-success"><i class="fa fa-tag" aria-hidden="true"></i> Nuevo Producto</button>
<p></p>
      <table class="table">
        <tbody id="thetbodyproductos"> 
        </tbody> 
      </table>
';

// Creacion de nuevos Productos
echo'
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><i class="fa fa-shopping-basket" aria-hidden="true"></i> Nuevo Producto</h4>
      </div>
      <div class="modal-body">
         <form id="ProductosForm">
            <label>Nombre:</label>
            <input type="text" name="nombre" class="form-control">
            <label>Categorias:</label>
            <select name="categoria" class="form-control">
              <option disabled selected></option>
              ';
              categoriasSelect();
              echo'
            </select>
            <label>Precio:</label>
            <input type="text" name="precio" class="form-control">
            <label>Cantidad</label>
            <input type="number" name="cantidad" min="1" value="1" class="form-control">
         </form>
      </div>
      <div class="modal-footer">
        <button type="button" onclick="nuevoProducto();" class="btn btn-primary">Guardar</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      </div>
    </div>
  </div>
</div>
';

$conexion = null;

}else{

echo'
<a onclick="closecontent();" id="closecontent"><i class="fa fa-times-circle" aria-hidden="true"></i></a>

<button data-toggle="modal" data-target="#myModal" class="btn btn-sm btn-success"><i class="fa fa-tag" aria-hidden="true"></i> Nuevo Producto</button>
<p></p>
<table class="table">
      <tbody id="thetbodyproductos"> 

';

foreach ($resultados as $key){

    echo'
       <tr id="trClassPro'.$key['ProID'].'">
         <td><h3 class="ProTDName'.$key['ProID'].'">'.$key['ProName'].'<small class="preciPro ThePrecioData'.$key['ProID'].'">$'.$key['ProPrecio'].'</small></h3><small class="smallProData'.$key['ProID'].'"><i class="fa fa-tag" aria-hidden="true"></i> '.$key['CatName'].'</small></td>
         <td class="text-right">
           <button class="btn btn-sm btn-primary" onclick="EditProducto('.$key['ProID'].')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Editar</button>
           <button class="btn btn-sm btn-danger" onclick="DeleteProducto('.$key['ProID'].')"><i class="fa fa-trash-o" aria-hidden="true"></i> Eliminar</button>
         </td>
       </tr>
    ';


}

// Final de la Tabla
echo'
       </tbody> 
      </table>
';

// Creacion de nuevos Productos
echo'
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><i class="fa fa-shopping-basket" aria-hidden="true"></i> Nuevo Producto</h4>
      </div>
      <div class="modal-body">
         <form id="ProductosForm">
            <label>Nombre:</label>
            <input type="text" name="nombre" class="form-control">
            <label>Categorias:</label>
            <select name="categoria" class="form-control">
              <option disabled selected></option>
              ';
              categoriasSelect();
              echo'
            </select>
            <label>Precio:</label>
            <input type="text" name="precio" class="form-control">
            <label>Cantidad</label>
            <input type="number" name="cantidad" min="1" value="1" class="form-control">
         </form>
      </div>
      <div class="modal-footer">
        <button type="button" onclick="nuevoProducto();" class="btn btn-primary">Guardar</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      </div>
    </div>
  </div>
</div>
';


}




#................................................................................	
}elseif ($process == 4){
#.................................................................................
checksessionrequest();
isadmin();

$SQL = 'SELECT * FROM usuarios';
$sentence = $conexion -> prepare($SQL);
$sentence -> execute();
$resultados = $sentence -> fetchAll();
if (empty($resultados)){
	# code...
}else{
	echo '
      <a onclick="closecontent();" id="closecontent"><i class="fa fa-times-circle" aria-hidden="true"></i></a>
      <button data-toggle="modal" data-target="#myModal" class="btn btn-sm btn-success"><i class="fa fa-user-plus" aria-hidden="true"></i> Nuevo Usuario</button>
      <p></p>
	  <table class="table">
      <tbody id="tbodyusuarios">
	  ';
	foreach ($resultados as $key){

        if ($key['rango'] == 1){
        	$therango = 'Usuario';
        }elseif ($key['rango'] == 2){
        	$therango = 'Administrador';
        }

		echo'
           <tr id="TrUsuario'.$key['id'].'">
              <td><h3 class="UserTDName'.$key['id'].'"><i class="fa fa-user-o" aria-hidden="true"></i> '.$key['usuario'].'</h3></td>
              <td><h4 class="UserRankData'.$key['id'].'">'.$therango.'</h4></td>
              <td class="text-right">
                 <button onclick="EditUsuarios('.$key['id'].')" class="btn btn-sm btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Editar</button>
                 <button onclick="DeleteUsuarios('.$key['id'].')" class="btn btn-sm btn-danger"><i class="fa fa-trash-o" aria-hidden="true"></i> Eliminar</button>
              </td>
           </tr>
		';
	}
	echo'
	  </tbody>
	  </table>
	  ';
}


// Creacion de nuevos Productos
echo'
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><i class="fa fa-user-plus" aria-hidden="true"></i> Nuevo Usuario</h4>
      </div>
      <div class="modal-body">

         <div id="UserExistNotification" class="alert alert-danger" role="alert"><i class="fa fa-minus-circle" aria-hidden="true"></i> Este usuario ya existe! prueba con otro.</div>


         <form id="NuevoUsuarioFrm">
            <label>Usuario:</label>
            <input type="text" name="usuario" class="form-control">
            <label>Contraseña:</label>
            <input type="password" name="password" class="form-control">
            <label>Rango:</label>
            <select class="form-control" name="rango">
                <option value="1">Usuario</option>
                <option value="2">Administrador</option>
            </select>
         </form>
      </div>
      <div class="modal-footer">
        <button type="button" onclick="nuevoUsuario();" class="btn btn-primary">Guardar</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      </div>
    </div>
  </div>
</div>
';




#................................................................................	
}elseif ($process == 5){
#.................................................................................








#................................................................................	
}elseif ($process == 6){
#.................................................................................
checksessionrequest();
isadmin();

echo'<a onclick="closecontent();" id="closecontent"><i class="fa fa-times-circle" aria-hidden="true"></i></a>';


// Suma del dia
$thefecha = date('Y-m-d');

$SQL = 'SELECT SUM(total) AS totalventas FROM ventas WHERE fecha = :fecha';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':fecha',$thefecha,PDO::PARAM_STR);
$sentence -> execute();
$resultados = $sentence -> fetchAll();
if (empty($resultados)){
  # code...
}else{
   foreach ($resultados as $key){
      
         echo '<h1 id="totaldateventas"><p>Total De Ganacias del Dia:</p> <p>$'.$key['totalventas'].'</p></h1>';

   }
}




echo'

<div class="input-group">
  <form id="formFilterDate">
  <input type="text" class="form-control" id="filtradofecha" name="filtradofecha" placeholder="Filtrador por Fecha...">
  </form>
  <span class="input-group-btn">
    <button onclick="filtrarFecha();" class="btn btn-default" type="button"><i class="fa fa-search" aria-hidden="true"></i> <i class="fa fa-calendar" aria-hidden="true"></i> Filtrar</button>
  </span>
</div><!-- /input-group -->

<p></p>

<table class="table">
  <tbody id="thefiltrofechabody">
';

$SQLTable = 'SELECT usuarios.usuario, ventas.ticket, ventas.fechaseconds, ventas.id FROM ventas INNER JOIN usuarios ON usuarios.id = ventas.usuario WHERE DATE(ventas.fecha) = :fecha ORDER BY ventas.fecha ASC';
$sentencetable = $conexion -> prepare($SQLTable);
$sentencetable -> bindParam(':fecha',$thefecha,PDO::PARAM_STR);
$sentencetable -> execute();
$resultadostable = $sentencetable -> fetchAll();
if (empty($resultadostable)){
  # code...
}else{
   foreach ($resultadostable as $key2){

       $fecha = str_replace('-', '/', date("d-m-Y h:i:s", strtotime($key2['fechaseconds'])));

       echo'
         <tr>
            <td class="text-left">';   getProDataVenta($key2['ticket']);   echo'</td>
            <td class="text-center">
               <p><i class="fa fa-user-o" aria-hidden="true"></i> '.$key2['usuario'].'</p>
               <p><i class="fa fa-calendar" aria-hidden="true"></i> '.$fecha.'</p>
            </td>
         </tr>
       ';
   }
}

echo'
  </tbody>
</table>
<script type="text/javascript">
$(function(){
    $("#filtradofecha").datetimepicker({
                 format: "DD-MM-YYYY"
           });
});  
</script>
';



#................................................................................	
}elseif ($process == 7){
#.................................................................................
checksessionrequest();
isadmin();

// Crear Categorias Nuevas
$filter = new InputFilter();
$firstnombre = $filter->process($_POST['nombre']);
$nombre = simpleFilterSpace($firstnombre);
$SQL = 'INSERT INTO categorias(nombre) VALUES(:nombre)';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':nombre', $nombre, PDO::PARAM_STR);
$sentence -> execute();
$lastid = $conexion -> lastInsertId();
$conexion = null;

echo' 
<tr id="trClass'.$lastid.'">
  <td><h3 class="CatNameTD'.$lastid.'">'.$nombre.'</h3></td>
  <td class="text-right">
    <button class="btn btn-sm btn-primary" onclick="EditCategoria('.$lastid.')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Editar</button>
    <button class="btn btn-sm btn-danger"  onclick="DeleteCategoria('.$lastid.')"><i class="fa fa-trash-o" aria-hidden="true"></i> Eliminar</button>
  </td>
</tr>
';



#................................................................................	
}elseif ($process == 8){
#.................................................................................
checksessionrequest();
isadmin();

// Editar Categorias
$categoria = $_POST['categoria'];

$SQL = 'SELECT * FROM categorias WHERE id = :id';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':id',$categoria, PDO::PARAM_INT);
$sentence -> execute();
$resultados = $sentence -> fetchAll();
if (empty($resultados)){
	$conexion = null;
}else{
   foreach ($resultados as $key){
   	
echo'
<!-- Modal -->
<div class="modal fade" id="myModalEdit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><i class="fa fa-tag" aria-hidden="true"></i> Nueva Categoria</h4>
      </div>
      <div class="modal-body">
         <form id="categoriaFormEdit">
            <label>Nombre:</label>
            <input type="text" name="nombre" class="form-control" value="'.$key['nombre'].'">
         </form>
      </div>
      <div class="modal-footer">
        <button type="button" onclick="SaveChangeCategoria('.$key['id'].');" class="btn btn-primary">Guardar</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      </div>
    </div>
  </div>
</div>
';

   }
}

$conexion = null;

#................................................................................	
}elseif ($process == 9){
#.................................................................................
checksessionrequest();
isadmin();


// Actualizar Categorias
$filter = new InputFilter();
$nombre = $filter->process($_POST['nombre']);
$id = $_POST['categoria'];

$SQL = 'UPDATE categorias SET nombre = :nombre WHERE id = :id';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':nombre', $nombre, PDO::PARAM_STR);
$sentence -> bindParam(':id', $id, PDO::PARAM_INT);
$sentence -> execute();

echo $nombre;

#................................................................................	
}elseif ($process == 10){
#.................................................................................
checksessionrequest();
isadmin();

$id = $_POST['categoria'];


// Borrar categoria
$SQL = 'DELETE FROM categorias WHERE id = :id';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':id', $id, PDO::PARAM_INT);
$sentence -> execute();


// Borrar productos segun categoria
$SQL = 'DELETE FROM productos WHERE categoria = :categoria';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':categoria', $id, PDO::PARAM_INT);
$sentence -> execute();

$conexion = null;

#................................................................................
}elseif ($process == 11) {
#.................................................................................
checksessionrequest();
isadmin();

// Crear Categorias Nuevas
$filter = new InputFilter();
$firstnombre = $filter->process($_POST['nombre']);
$nombre = simpleFilterSpace($firstnombre);
$categoria = $_POST['categoria'];
$cantidad = $_POST['cantidad'];
$firstprecio = $_POST['precio'];
$precio = simpleFilterSpace($firstprecio);

$SQL = 'INSERT INTO productos(nombre,categoria,cantidad,precio) VALUES(:nombre,:categoria,:cantidad,:precio)';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':nombre', $nombre, PDO::PARAM_STR);
$sentence -> bindParam(':categoria', $categoria, PDO::PARAM_STR);
$sentence -> bindParam(':cantidad', $cantidad, PDO::PARAM_STR);
$sentence -> bindParam(':precio', $precio, PDO::PARAM_STR);
$sentence -> execute();
$lastid = $conexion -> lastInsertId();
$conexion = null;

$CatName = getNameCategory($categoria);

echo'
   <tr id="trClassPro'.$lastid.'">
     <td><h3 class="ProTDName'.$lastid.'">'.$nombre.'<small class="preciPro ThePrecioData'.$lastid.'">$'.$precio.'</small></h3><small class="smallProData'.$lastid.'"><i class="fa fa-tag" aria-hidden="true"></i> '.$CatName.'</small></td>
     <td class="text-right">
       <button class="btn btn-sm btn-primary" onclick="EditProducto('.$lastid.')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Editar</button>
       <button class="btn btn-sm btn-danger" onclick="DeleteProducto('.$lastid.')"><i class="fa fa-trash-o" aria-hidden="true"></i> Eliminar</button>
     </td>
   </tr>
';

$conexion = null;
#.................................................................................	
}elseif ($process == 12) {
#.................................................................................
checksessionrequest();
isadmin();

// Editar Categorias
$producto = $_POST['producto'];

$SQL = 'SELECT * FROM productos WHERE id = :id';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':id',$producto, PDO::PARAM_INT);
$sentence -> execute();
$resultados = $sentence -> fetchAll();
if (empty($resultados)){
	$conexion = null;
}else{
   foreach ($resultados as $key){
   	
echo'
<!-- Modal -->
<div class="modal fade" id="myModalEdit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><i class="fa fa-tag" aria-hidden="true"></i> Editar Producto</h4>
      </div>
      <div class="modal-body">
         <form id="ProductosFormEdit">
            <label>Nombre:</label>
            <input type="text" name="nombre" class="form-control" value="'.$key['nombre'].'">
            <label>Categorias:</label>
            <select name="categoria" class="form-control">
              ';
              echo'<optgroup>';
              categoriasSelectPerID($key['id']);
              echo'</optgroup>';
              echo'<optgroup>';
              categoriasSelect();
              echo'</optgroup>';
              echo'
            </select>
            <label>Precio:</label>
            <input type="text" name="precio" class="form-control" value="'.$key['precio'].'">
            <label>Cantidad</label>
            <input type="number" name="cantidad" min="1" value="'.$key['cantidad'].'" class="form-control" >
         </form>
      </div>
      <div class="modal-footer">
        <button type="button" onclick="SaveChangeProducto('.$key['id'].');" class="btn btn-primary">Guardar</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      </div>
    </div>
  </div>
</div>
';

   }
}

$conexion = null;




#.................................................................................	
}elseif ($process == 13) {
#.................................................................................
checksessionrequest();
isadmin();


// Actualizar Categorias
$filter = new InputFilter();

$firstnombre = $filter->process($_POST['nombre']);
$nombre = simpleFilterSpace($firstnombre);
$categoria = $_POST['categoria'];
$cantidad = $_POST['cantidad'];
$precio = $_POST['precio'];
$id = $_POST['producto'];

$SQL = 'UPDATE productos SET nombre = :nombre, categoria = :categoria, cantidad = :cantidad, precio = :precio WHERE id = :id';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':nombre', $nombre, PDO::PARAM_STR);
$sentence -> bindParam(':categoria', $categoria, PDO::PARAM_INT);
$sentence -> bindParam(':cantidad', $cantidad, PDO::PARAM_STR);
$sentence -> bindParam(':precio', $precio, PDO::PARAM_STR);
$sentence -> bindParam(':id', $id, PDO::PARAM_INT);
$sentence -> execute();
$conexion = null;

$categoryname = getNameCategory($categoria);

$productojson = array ("nombre" => $nombre,"categoria" => $categoryname,"precio" => $precio);
echo json_encode($productojson);

#.................................................................................	
}elseif ($process == 14) {
#.................................................................................
checksessionrequest();
isadmin();

$id = $_POST['producto'];

// Borrar productos segun categoria
$SQL = 'DELETE FROM productos WHERE id = :id';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':id', $id, PDO::PARAM_INT);
$sentence -> execute();
$conexion = null;


#.................................................................................	
}elseif ($process == 15) {
#.................................................................................
checksessionrequest();
isadmin();

// Crear Categorias Nuevas
$filter = new InputFilter();
$firstusuario = $filter->process($_POST['usuario']);
$usuario = simpleFilterSpace($firstusuario);

$verifyuser = checkusernameDB($usuario);

if ($verifyuser == 1){
#//////////////////////////////////////////////////////////////////////////////////////
$SAL = 'AWR004z5o8Ub6Fb8hM4Qijy5UyJn736t';
$PIMIENTA = 'qYfd010Ca4UGPUA6MY6pY51Zklv7GVjY';
$ResCrypt = sha1($SAL.$_POST['password'].$PIMIENTA);
$rango = $_POST['rango'];

$SQL = 'INSERT INTO usuarios(usuario,password,rango) VALUES(:usuario,:password,:rango)';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':usuario', $usuario, PDO::PARAM_STR);
$sentence -> bindParam(':password', $ResCrypt, PDO::PARAM_STR);
$sentence -> bindParam(':rango', $rango, PDO::PARAM_STR);
$sentence -> execute();
$lastid = $conexion -> lastInsertId();
$conexion = null;

if ($rango == 1) {
	$finalrango = 'Usuario';
}elseif ($rango == 2) {
	$finalrango = 'Administrador';
}

echo' 
<tr id="TrUsuario'.$lastid.'">
  <td><h3 class="UserTDName'.$lastid.'"><i class="fa fa-user-o" aria-hidden="true"></i> '.$usuario.'</h3></td>
  <td><h4 class="UserRankData'.$lastid.'">'.$finalrango.'</h4></td>
  <td class="text-right">
    <button class="btn btn-sm btn-primary" onclick="EditUsuarios('.$lastid.')"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Editar</button>
    <button class="btn btn-sm btn-danger"  onclick="DeleteUsuarios('.$lastid.')"><i class="fa fa-trash-o" aria-hidden="true"></i> Eliminar</button>
  </td>
</tr>
';
#//////////////////////////////////////////////////////////////////////////////////////
}elseif ($verifyuser == 2){
#//////////////////////////////////////////////////////////////////////////////////////
echo 2;
#//////////////////////////////////////////////////////////////////////////////////////
}


#.................................................................................	
}elseif ($process == 16) {
#.................................................................................

checksessionrequest();
isadmin();

// Editar Categorias
$usuario = $_POST['usuario'];

$SQL = 'SELECT * FROM usuarios WHERE id = :id';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':id',$usuario, PDO::PARAM_INT);
$sentence -> execute();
$resultados = $sentence -> fetchAll();
if (empty($resultados)){
	$conexion = null;
}else{
   foreach ($resultados as $key){
   	
   if ($key['rango'] == 1){
   	  $rangodata = '
        <option value="1">Usuario</option>
        <option value="2">Administrador</option>
   	  ';
   }elseif ($key['rango'] == 2){
   	  $rangodata = '
        <option value="2">Administrador</option>
        <option value="1">Usuario</option>
   	  ';
   }


echo'
<!-- Modal -->
<div class="modal fade" id="myModalEdit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><i class="fa fa-user-o" aria-hidden="true"></i> Editar Usuario</h4>
      </div>
      <div class="modal-body">
         <form id="UsuariosFrmEdit">
            <label>Usuario:</label>
            <input type="text" name="usuario" class="form-control" value="'.$key['usuario'].'">
            <label>Nueva Contraseña:</label>
            <input type="password" name="password" class="form-control">
            <label>Rango:</label>
            <select class="form-control" name="rango">
                '.$rangodata.'
            </select>
         </form>
      </div>
      <div class="modal-footer">
        <button type="button" onclick="SaveChangeUsuario('.$key['id'].');" class="btn btn-primary">Guardar</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
      </div>
    </div>
  </div>
</div>
';

   }
}

$conexion = null;



#.................................................................................	
}elseif ($process == 17) {
#.................................................................................


checksessionrequest();
isadmin();

// Crear Categorias Nuevas
$filter = new InputFilter();
$firstusuario = $filter->process($_POST['usuario']);
$usuario = simpleFilterSpace($firstusuario);
$id = $_POST['iduser'];

$verifyuser = checkusernameDB($usuario);

if ($verifyuser == 1){
#//////////////////////////////////////////////////////////////////////////////////////
$SAL = 'AWR004z5o8Ub6Fb8hM4Qijy5UyJn736t';
$PIMIENTA = 'qYfd010Ca4UGPUA6MY6pY51Zklv7GVjY';
$ResCrypt = sha1($SAL.$_POST['password'].$PIMIENTA);
$rango = $_POST['rango'];

if (empty($_POST['password'])) {

$SQL = 'UPDATE usuarios SET usuario = :usuario, rango = :rango WHERE id = :id';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':usuario', $usuario, PDO::PARAM_STR);
$sentence -> bindParam(':rango', $rango, PDO::PARAM_STR);
$sentence -> bindParam(':id', $id, PDO::PARAM_STR);
$sentence -> execute();
$lastid = $conexion -> lastInsertId();
$conexion = null;

}else{

$SQL = 'UPDATE usuarios SET usuario = :usuario, password = :password, rango = :rango WHERE id = :id';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':usuario', $usuario, PDO::PARAM_STR);
$sentence -> bindParam(':password', $ResCrypt, PDO::PARAM_STR);
$sentence -> bindParam(':rango', $rango, PDO::PARAM_STR);
$sentence -> bindParam(':id', $id, PDO::PARAM_STR);
$sentence -> execute();
$lastid = $conexion -> lastInsertId();
$conexion = null;

}

if ($rango == 1){
	$therangodatatext = 'Usuario';
}elseif ($rango == 2){
	$therangodatatext = 'Administrador';
}


$usuariosjson = array ("usuario" => $usuario,"rango" => $therangodatatext);
echo json_encode($usuariosjson);

#//////////////////////////////////////////////////////////////////////////////////////
}elseif ($verifyuser == 2){
#//////////////////////////////////////////////////////////////////////////////////////
$usuariosjson = array ("erroruser" => 2);
echo json_encode($usuariosjson);
#//////////////////////////////////////////////////////////////////////////////////////
}


#.................................................................................	
}elseif ($process == 18) {
#.................................................................................
checksessionrequest();
isadmin();

$id = $_POST['usuario'];

if ($id == $_SESSION['idsession']) {
    exit;
}

// Borrar categoria
$SQL = 'DELETE FROM usuarios WHERE id = :id';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':id', $id, PDO::PARAM_INT);
$sentence -> execute();
$conexion = null;

#.................................................................................	
}elseif ($process == 19) {
#.................................................................................

$categoria = $_POST['categoria'];
GETproductosCaja($categoria);


#.................................................................................	
}elseif ($process == 20) {
#.................................................................................

$thedata = $_POST['cadena'];
$dellaststr = substr($thedata, 0, -1);
$firstexplode = explode(",", $dellaststr);
$countexplode = count($firstexplode);


for ($i = $countexplode; $i >= 0; $i--) {
	  $thedatasum += getDataProductsVenta($firstexplode[$i]);
}

   guardarVenta($dellaststr,$thedatasum);

#.................................................................................	
}elseif ($process == 21) {
#.................................................................................


$fecha = date("Y-m-d", strtotime($_POST['filtradofecha']));

$SQL = 'SELECT usuarios.usuario, ventas.ticket, ventas.fechaseconds, ventas.id FROM ventas INNER JOIN usuarios ON usuarios.id = ventas.usuario WHERE DATE(ventas.fecha) = :fecha ORDER BY ventas.fecha ASC';
$sentence = $conexion -> prepare($SQL);
$sentence -> bindParam(':fecha', $fecha ,PDO::PARAM_STR);
$sentence -> execute();
$resultados = $sentence -> fetchAll();
if (empty($resultados)){
  # code...
}else{
  foreach ($resultados as $key){

       $fecharight = str_replace('-', '/', date("d-m-Y h:i:s", strtotime($key['fechaseconds'])));
       echo'
         <tr>
            <td class="text-left">';   getProDataVenta($key['ticket']);   echo'</td>
            <td class="text-center">
               <p><i class="fa fa-user-o" aria-hidden="true"></i> '.$key['usuario'].'</p>
               <p><i class="fa fa-calendar" aria-hidden="true"></i> '.$fecharight.'</p>
            </td>
         </tr>
       ';

    }
}


#.................................................................................	
}


//--------------------------------------------------------------------------------
}else{
	exit;
}
//--------------------------------------------------------------------------------	
}else{
	exit;
}
