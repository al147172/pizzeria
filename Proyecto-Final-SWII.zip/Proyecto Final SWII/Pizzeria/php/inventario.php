<!DOCTYPE html>
<?php

require_once '../includes/resfunctions.php';
checklogin();

?>
<html>
	<head>
		<title>Resultados de la busqueda</title>
		<meta charset="UTF-8">
		<link href="../css/estilos.css" rel="stylesheet">
		</head>
	<body>
	
	<?php
		$conexion = mysqli_connect("localhost","root","","restaurantv4") or die("Problema en la conexion");
		$consulta = $conexion->query("SELECT * FROM ingredientes");
		
		
		
		echo "<table class ='tabla'>";
		echo "<tr><th>Id</th><th>Nombre</th><th>Cantidad</th></tr>";
		$id_ing=1;
		while($renglon = $consulta->fetch_array())
		{
			echo "<tr><td> $id_ing	</td>";
			echo "<td>".$renglon["nombre"]."</td>";
			echo "<td>".$renglon["cantidad"]."</td> </tr>";
			$id_ing=$id_ing+1;
		}
		echo "</table>";
		
		$consulta->free();
		$conexion->close();
		echo "<a href='../panel.php' class='BotonAbastecerCancelar' style='text-decoration:none'>Regresar a la pagina principal</a>";	
	?>
	<form action="modificarupdatesql.php" method="get">
	Introduzca el numero del ingrediente a abastecer: <input type="text"  name="idingr"><br>
	
	<input type="submit" value="Abastecer"class="BotonAbastecerCancelar">
	</form>
	
	
	</body>
</html>