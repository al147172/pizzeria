<!DOCTYPE html>
<?php

require_once '../includes/resfunctions.php';
checklogin();

?>

<html>
	<head>
		<title>Registro de alumno</title>
		<meta charset="UTF-8">
		<link href="../css/estilos.css" rel="stylesheet">
		</head>
	<body>
<?php
	if(isset($_REQUEST['idingr']) )
	{
			$id_ingr= $_REQUEST['idingr'];
			$conexion = mysqli_connect("127.0.0.1","root","","restaurantv4") or die("Problema en la conexion");
			$consulta = $conexion->query("SELECT * FROM ingredientes");
		
			$query = "UPDATE ingredientes SET cantidad = 1000 WHERE id = '$id_ingr'";
			
			
			mysqli_query($conexion,$query) or die("Problema en seleccion de BD".mysql_error());
			mysqli_close($conexion);
			
			echo "Datos actualizados...";
			//echo "$id_ingr"; //El isset no funciona 
			echo "<br>";
			echo "<a href='../index.php' class='BotonAbastecerCancelar' style='text-decoration:none'>Regresar a la pagina principal</a>";	
	}
	else
	{
		echo "<br> No se ingreso algun dato<br>";
		echo "<a href='../index.php class='BotonAbastecerCancelar' style='text-decoration:none'>Regresar a la pagina principal</a>";	
	}


?>


	</body>
</html>