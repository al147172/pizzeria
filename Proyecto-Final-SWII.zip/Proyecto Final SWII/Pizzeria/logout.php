<?php

session_start();session_regenerate_id();unset($_SESSION['idsession']);unset($_SESSION['ranksession']);session_destroy();header('Location: index.php');
